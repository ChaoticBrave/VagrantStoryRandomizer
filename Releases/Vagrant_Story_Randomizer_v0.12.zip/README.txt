Vagrant Story Randomizer
========================

Changelog:

0.01 (04/04/2022): Basic enemy randomizer using Python.
0.10 (10/04/2022): Added random drop randomization.
0.12 (12/04/2022): Altered rooms with treasure chests so that they actually randomize.


=========================

Instructions:

1) Insert your Vagrant Story bin file into the unzipped randomizer folder.
2) Open vagrant_story_randomizer.
3) Enter the name of your Vagrant Story bin file.
4) Let the randomizer run. It will tell you when the process is completed, then close itself after 3 seconds.

============================

Credits:

ChaoticBrave: For making the randomizer of course!
Valendian: For the extensive knowledge in Vagrant Story's file systems, as well as creating the superb VSTOOLS and GodHands packages.
Christo: For the idea of creating a randomizer in the first place.
CUE: For the psx-mode2 tool. The project would've been lost without it.
gingerbeardman: For letting me use his translation of psx-mode2.
NoharOSP: For being at hand to test this locally.


